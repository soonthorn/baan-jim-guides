"""Windows desktop app for the two MakHam voices."""

import json
import os
import queue
import re
import tempfile
import threading
import tkinter as tk
import winsound
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import numpy as np
import soundfile as sf


APP_DIR = Path(__file__).resolve().parent
SETTINGS_FILE = APP_DIR / "settings.json"
DEFAULT_CACHE = APP_DIR.parent / "MakHamTTS" / "hf-cache"
os.environ.setdefault("HF_HOME", str(DEFAULT_CACHE if DEFAULT_CACHE.exists() else APP_DIR / "hf-cache"))
MAX_CHARS = 80


def split_text(text: str) -> list[str]:
    """Split long Thai text into model-safe phrases, keeping sentence punctuation."""
    phrases = []
    for line in text.replace("\r", "").split("\n"):
        for sentence in re.findall(r"[^.!?。！？]+[.!?。！？]?", line):
            remaining = sentence.strip()
            while len(remaining) > MAX_CHARS:
                cut = max(remaining.rfind(" ", 0, MAX_CHARS + 1), remaining.rfind("，", 0, MAX_CHARS + 1))
                if cut < MAX_CHARS // 2:
                    cut = MAX_CHARS
                chunk = remaining[:cut].strip()
                if chunk:
                    phrases.append(chunk)
                remaining = remaining[cut:].strip()
            if remaining:
                phrases.append(remaining)
    return phrases


def synthesize(text: str, voice: str, speed: float, pitch: float, volume: float,
               pause: float, output: Path, progress, canceled) -> tuple[int, float]:
    """Render phrases to one WAV file; raise if canceled or a phrase fails."""
    from pythaitts import TTS

    phrases = split_text(text)
    if not phrases:
        raise ValueError("กรุณาใส่ข้อความก่อนสร้างเสียง")
    tts = TTS(pretrained="makham")
    clips = []
    sample_rate = None
    with tempfile.TemporaryDirectory(dir=APP_DIR) as temp_dir:
        for index, phrase in enumerate(phrases, start=1):
            if canceled.is_set():
                raise InterruptedError("ยกเลิกแล้ว")
            progress(index - 1, len(phrases), f"กำลังสร้างช่วงที่ {index}/{len(phrases)}")
            segment = Path(temp_dir) / f"segment-{index}.wav"
            tts.tts(phrase, speaker_idx=voice, speed=speed, filename=str(segment))
            audio, rate = sf.read(segment, dtype="float32")
            if sample_rate is None:
                sample_rate = rate
            elif rate != sample_rate:
                raise RuntimeError("อัตราสุ่มเสียงไม่ตรงกัน")
            if pitch:
                import librosa
                audio = librosa.effects.pitch_shift(audio, sr=rate, n_steps=pitch)
            audio = np.clip(audio * volume, -1.0, 1.0)
            clips.append(audio)
            if index < len(phrases) and pause:
                clips.append(np.zeros(int(rate * pause), dtype=np.float32))
        if canceled.is_set():
            raise InterruptedError("ยกเลิกแล้ว")
        output.parent.mkdir(parents=True, exist_ok=True)
        sf.write(output, np.concatenate(clips), sample_rate)
    progress(len(phrases), len(phrases), "เสร็จแล้ว")
    return len(phrases), sum(len(clip) for clip in clips) / sample_rate


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("MakHam Voice Studio")
        self.geometry("760x600")
        self.minsize(500, 400)
        self.configure(bg="#f4f6f8")
        self.cancel_event = threading.Event()
        self.events = queue.Queue()
        self.worker = None
        self.last_audio = None
        self.output = tk.StringVar(value=str(APP_DIR / "output.wav"))
        self.voice = tk.StringVar(value="newvoice_female")
        self.speed = tk.DoubleVar(value=1.0)
        self.pitch = tk.DoubleVar(value=0.0)
        self.volume = tk.DoubleVar(value=1.0)
        self.pause = tk.DoubleVar(value=0.25)
        self.status = tk.StringVar(value="พร้อมสร้างเสียง")
        self._build_ui()
        self._load_settings()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _build_ui(self):
        style = ttk.Style(self)
        if "vista" in style.theme_names():
            style.theme_use("vista")
        outer = ttk.Frame(self, padding=12)
        outer.pack(fill="both", expand=True)

        ttk.Label(outer, text="MakHam Voice Studio", font=("Segoe UI", 16, "bold")).pack(anchor="w")
        ttk.Label(outer, text="สร้างเสียงภาษาไทยด้วยเสียงหญิงหรือชาย", font=("Segoe UI", 9)).pack(anchor="w", pady=(0, 8))

        footer = ttk.Frame(outer)
        footer.pack(side="bottom", fill="x")
        tabs = ttk.Notebook(outer)
        tabs.pack(fill="both", expand=True)
        text_tab = ttk.Frame(tabs, padding=7)
        settings_tab = ttk.Frame(tabs, padding=7)
        tabs.add(text_tab, text="ข้อความ")
        tabs.add(settings_tab, text="ตั้งค่าเสียง")

        text_header = ttk.Frame(text_tab)
        text_header.pack(fill="x")
        ttk.Label(text_header, text="พิมพ์หรือวางข้อความที่ต้องการอ่าน").pack(side="left")
        ttk.Button(text_header, text="เปิดไฟล์ .txt", command=self._open_text).pack(side="right")
        text_frame = ttk.Frame(text_tab)
        text_frame.pack(fill="both", expand=True, pady=(7, 0))
        self.text = tk.Text(text_frame, wrap="word", undo=True, font=("Segoe UI", 11), padx=10, pady=8)
        scroll = ttk.Scrollbar(text_frame, orient="vertical", command=self.text.yview)
        self.text.configure(yscrollcommand=scroll.set)
        self.text.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        canvas = tk.Canvas(settings_tab, highlightthickness=0)
        settings_scroll = ttk.Scrollbar(settings_tab, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=settings_scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        settings_scroll.pack(side="right", fill="y")
        settings = ttk.Frame(canvas, padding=5)
        settings_window = canvas.create_window((0, 0), window=settings, anchor="nw")
        settings.bind("<Configure>", lambda _: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda event: canvas.itemconfigure(settings_window, width=event.width))
        canvas.bind("<Enter>", lambda _: canvas.bind_all("<MouseWheel>", lambda event: canvas.yview_scroll(-int(event.delta / 120), "units")))
        canvas.bind("<Leave>", lambda _: canvas.unbind_all("<MouseWheel>"))
        voice_row = ttk.Frame(settings)
        voice_row.pack(fill="x", pady=(0, 9))
        ttk.Label(voice_row, text="เสียง", width=16).pack(side="left")
        ttk.Radiobutton(voice_row, text="ผู้หญิง", variable=self.voice, value="newvoice_female").pack(side="left", padx=(0, 18))
        ttk.Radiobutton(voice_row, text="ผู้ชาย", variable=self.voice, value="newvoice_male").pack(side="left")
        self._scale(settings, "ความเร็ว", self.speed, 0.6, 1.5, "×", 0.05)
        self._scale(settings, "ทุ้ม / แหลม", self.pitch, -4.0, 4.0, " ครึ่งเสียง", 0.5)
        self._scale(settings, "ความดัง", self.volume, 0.2, 2.0, "×", 0.1)
        self._scale(settings, "พักระหว่างช่วง", self.pause, 0.0, 1.5, " วินาที", 0.05)
        ttk.Label(settings, text="ทุ้ม/แหลมและความดังปรับหลังสังเคราะห์เสียง", foreground="#656b73").pack(anchor="w", pady=(8, 0))

        output_row = ttk.Frame(footer)
        output_row.pack(fill="x", pady=(9, 6))
        ttk.Label(output_row, text="ไฟล์ WAV").pack(side="left")
        ttk.Entry(output_row, textvariable=self.output).pack(side="left", fill="x", expand=True, padx=7)
        ttk.Button(output_row, text="เลือกที่บันทึก", command=self._choose_output).pack(side="left")

        actions = ttk.Frame(footer)
        actions.pack(fill="x")
        self.start_button = ttk.Button(actions, text="สร้างไฟล์เสียง", command=self._start)
        self.start_button.pack(side="left")
        self.cancel_button = ttk.Button(actions, text="ยกเลิก", command=self.cancel_event.set, state="disabled")
        self.cancel_button.pack(side="left", padx=(6, 12))
        self.play_button = ttk.Button(actions, text="▶ ฟังเสียง", command=self._play_audio, state="disabled")
        self.play_button.pack(side="left")
        self.stop_button = ttk.Button(actions, text="■ หยุด", command=self._stop_audio, state="disabled")
        self.stop_button.pack(side="left", padx=6)
        ttk.Button(actions, text="เปิดโฟลเดอร์ไฟล์", command=self._open_output_folder).pack(side="right")
        self.progress = ttk.Progressbar(footer, mode="determinate", maximum=100)
        self.progress.pack(fill="x", pady=(9, 4))
        ttk.Label(footer, textvariable=self.status).pack(anchor="w")

    def _scale(self, parent, label, variable, low, high, suffix, step):
        row = ttk.Frame(parent)
        row.pack(fill="x", pady=2)
        ttk.Label(row, text=label, width=16).pack(side="left")
        value = ttk.Label(row, width=15)
        value.pack(side="right")

        def update(raw):
            rounded = round(float(raw) / step) * step
            variable.set(round(rounded, 2))
            value.configure(text=f"{variable.get():g}{suffix}")

        scale = ttk.Scale(row, from_=low, to=high, command=update)
        scale.set(variable.get())
        scale.pack(side="left", fill="x", expand=True, padx=8)
        variable.trace_add("write", lambda *_: value.configure(text=f"{variable.get():g}{suffix}"))

    def _open_text(self):
        path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
        if path:
            try:
                content = Path(path).read_text(encoding="utf-8-sig")
            except Exception as exc:
                messagebox.showerror("เปิดไฟล์ไม่สำเร็จ", str(exc))
                return
            self.text.delete("1.0", "end")
            self.text.insert("1.0", content)

    def _choose_output(self):
        path = filedialog.asksaveasfilename(defaultextension=".wav", filetypes=[("WAV audio", "*.wav")], initialfile=Path(self.output.get()).name)
        if path:
            self.output.set(path)

    def _open_output_folder(self):
        folder = Path(self.output.get()).expanduser().parent
        folder.mkdir(parents=True, exist_ok=True)
        os.startfile(folder)

    def _play_audio(self):
        if not self.last_audio or not self.last_audio.is_file():
            messagebox.showwarning("ไม่มีไฟล์เสียง", "กรุณาสร้างไฟล์เสียงก่อน")
            return
        try:
            winsound.PlaySound(str(self.last_audio), winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_NODEFAULT)
            self.stop_button.configure(state="normal")
            self.status.set(f"กำลังเล่น: {self.last_audio.name}")
        except RuntimeError as exc:
            messagebox.showerror("เล่นเสียงไม่สำเร็จ", str(exc))

    def _stop_audio(self):
        winsound.PlaySound(None, 0)
        self.stop_button.configure(state="disabled")
        if self.last_audio:
            self.status.set(f"หยุดเล่น: {self.last_audio.name}")

    def _start(self):
        if self.worker and self.worker.is_alive():
            return
        text = self.text.get("1.0", "end").strip()
        if not text:
            messagebox.showwarning("ยังไม่มีข้อความ", "กรุณาใส่ข้อความก่อนสร้างเสียง")
            return
        output = Path(self.output.get()).expanduser()
        if output.suffix.lower() != ".wav":
            messagebox.showwarning("ไฟล์ปลายทาง", "กรุณาใช้ชื่อไฟล์ .wav")
            return
        winsound.PlaySound(None, 0)
        self.stop_button.configure(state="disabled")
        self._save_settings()
        voice = self.voice.get()
        speed = self.speed.get()
        pitch = self.pitch.get()
        volume = self.volume.get()
        pause = self.pause.get()
        self.cancel_event.clear()
        self.start_button.configure(state="disabled")
        self.cancel_button.configure(state="normal")
        self.progress["value"] = 0
        self.status.set("กำลังโหลดโมเดล...")

        def progress(done, total, label):
            self.events.put(("progress", done, total, label))

        def work():
            try:
                count, seconds = synthesize(text, voice, speed, pitch, volume, pause, output, progress, self.cancel_event)
                self.events.put(("finish", f"บันทึกแล้ว: {output.name} · {seconds:.1f} วินาที · {count} ช่วง", None, output))
            except InterruptedError:
                self.events.put(("finish", "ยกเลิกแล้ว", None))
            except Exception as exc:
                self.events.put(("finish", "สร้างเสียงไม่สำเร็จ", str(exc)))

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()
        self.after(100, self._poll_events)

    def _poll_events(self):
        try:
            while True:
                event = self.events.get_nowait()
                if event[0] == "progress":
                    _, done, total, label = event
                    self.progress.configure(value=100 * done / total)
                    self.status.set(label)
                elif event[0] == "finish":
                    self._finish(event[1], event[2], event[3] if len(event) > 3 else None)
        except queue.Empty:
            pass
        if self.worker and self.worker.is_alive():
            self.after(100, self._poll_events)

    def _finish(self, status, error, output=None):
        self.start_button.configure(state="normal")
        self.cancel_button.configure(state="disabled")
        self.status.set(status)
        if output:
            self.last_audio = output
            self.play_button.configure(state="normal")
        if error:
            messagebox.showerror("เกิดข้อผิดพลาด", error)

    def _save_settings(self):
        data = {"voice": self.voice.get(), "speed": self.speed.get(), "pitch": self.pitch.get(),
                "volume": self.volume.get(), "pause": self.pause.get(), "output": self.output.get()}
        SETTINGS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def _load_settings(self):
        if not SETTINGS_FILE.exists():
            return
        try:
            data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
            for name in ("voice", "speed", "pitch", "volume", "pause", "output"):
                if name in data:
                    getattr(self, name).set(data[name])
        except (OSError, ValueError, tk.TclError):
            pass

    def _on_close(self):
        if self.worker and self.worker.is_alive():
            self.cancel_event.set()
        winsound.PlaySound(None, 0)
        self.destroy()


if __name__ == "__main__":
    App().mainloop()
