# MakHam Voice Studio

โปรแกรม Windows สำหรับสร้างเสียงไทยด้วย `newvoice_female` และ `newvoice_male` ผ่าน PyThaiTTS

1. ติดตั้ง Python 3.11 แบบ 64 บิตจาก https://www.python.org/downloads/ และเลือก Add python.exe to PATH
2. เปิด PowerShell ในโฟลเดอร์นี้ แล้วรัน:

```powershell
python -m venv .venv
& .\.venv\Scripts\python.exe -m pip install --upgrade pip
& .\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

3. ดับเบิลคลิก `run.cmd` เพื่อเปิดโปรแกรม

การสร้างเสียงครั้งแรกต้องใช้อินเทอร์เน็ตเพื่อดาวน์โหลดโมเดล หลังจากนั้นสร้างเสียงแบบออฟไลน์ได้ โปรแกรมเก็บโมเดลใน `hf-cache` ข้างไฟล์นี้

คู่มือพร้อมเสียงตัวอย่าง: https://soonthorn.github.io/baan-jim-guides/makham-voice-studio.html
