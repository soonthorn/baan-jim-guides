@echo off
set "APP_DIR=%~dp0"
if exist "%APP_DIR%.venv\Scripts\python.exe" (
  set "PYTHON=%APP_DIR%.venv\Scripts\python.exe"
) else if exist "%APP_DIR%..\MakHamTTS\.venv\Scripts\python.exe" (
  set "PYTHON=%APP_DIR%..\MakHamTTS\.venv\Scripts\python.exe"
) else (
  echo Python environment not found. See README.md.
  pause
  exit /b 1
)
"%PYTHON%" "%APP_DIR%app.py"
