$appDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$localPython = Join-Path $appDir '.venv\Scripts\python.exe'
$existingPython = Join-Path $appDir '..\MakHamTTS\.venv\Scripts\python.exe'

if (Test-Path -LiteralPath $localPython) {
    $python = $localPython
} elseif (Test-Path -LiteralPath $existingPython) {
    $python = $existingPython
} else {
    Write-Error 'ไม่พบ Python ของแอป กรุณาติดตั้งตาม README.md ก่อน'
    exit 1
}

& $python (Join-Path $appDir 'app.py')
